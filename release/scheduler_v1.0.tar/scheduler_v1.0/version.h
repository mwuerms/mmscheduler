// this file was automatically created by the Makefile, do not edit
#define cVERSION "v1.0"
